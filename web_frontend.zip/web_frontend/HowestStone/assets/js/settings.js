"use strict";
document.addEventListener("DOMContentLoaded", init);
let user = document.cookie;
// after the page is fully loaded: do this
if (user === ""){
    window.open("login.html",'_self');
}

function init() {
    document.querySelector('.option').innerHTML = user;
    document.querySelector(".settingsIcon").addEventListener("click", settings);
    document.querySelector(".closeMenu").addEventListener("click",closeSettings);
    document.querySelector(".switchAccount").addEventListener("click",logout);

}
// <editor-fold desc ="Akash"

function closeSettings() {
    console.log("closed");
    document.querySelector('.gameMenu').classList.toggle('hidden');
}

function settings(e) {
    e.preventDefault();
    console.log("Settings Geklikt");
    document.querySelector('.gameMenu').classList.toggle('hidden');
}
function logout() {
    document.cookie = "";
    window.open('login.html','_self');
}