'use strict';
document.addEventListener("DOMContentLoaded", init);

let deckNaam;
let cards;
let deckToPlayHunter;
let deckToPlayMage;
let selectedDeck;
let selectedDeckId;
let indexOfSelectedDeck;
let decksMage = [];
let decksHunter = [];
let selectedDecks = decksMage;
let activeClass = 'mage';
let JSON;

function init() {
    showDecks();
    document.querySelector('.use').addEventListener('click',useDeck);
    document.querySelector('.delete').addEventListener('click', deleteDeck);
    document.querySelector('.deckslist').addEventListener('click',addDeck);
    document.querySelector('.deckslist').addEventListener('click', selectDeck);
    document.querySelector('.parentclass').addEventListener('click', switchClass);

}

function loadJSON() {
    fetch("http://localhost:4242/game/getMinions",
        {
            headers: new Headers({
                "accept": "application/json",
            })
        })
        .then(function (response) {
            if (response.status !== 200) {
                throw ("help me");
            }
            return response.json();
        })
        .then(function (myJson) {
            cards = myJson;

        })
        .catch(function (error) {
            console.log(error);
        });
}

function loadBasicDeck(decks) {
    let basicDeck= cards.Mage;
    decks.push(basicDeck);
    console.log(decks.length);
    //TODO hardcodeDeck

}

function selectDeck(e) {
        if (!e.target.classList.contains("newdeck")) {
            document.querySelector(".selectedDeck").classList.remove('selectedDeck');
            console.log(e.target.className);
            indexOfSelectedDeck = parseInt(e.target.getAttribute('data-pos')) - 1;
            selectedDeckId = e.target.getAttribute('data-deckId');
            selectedDeck = selectedDecks[indexOfSelectedDeck];
            e.target.classList.add("selectedDeck");
            console.log(selectedDeck);
        }
}
function useDeck() {
    document.querySelector(".deckInUse").classList.remove('deckInUse');
    document.querySelector(".selectedDeck").classList.add('deckInUse');
    switch (activeClass){
        case "mage":
            deckToPlayMage= selectedDeck;
            break;
        case "hunter":
            deckToPlayHunter = selectedDeck;
    }
}

function addDeck(e) {
    let deckID = Math.random().toString(36).substr(2, 16);
    if (e.target.classList.contains("newdeck")){
        let extraDeck = [];
        selectedDeck = extraDeck;
        selectedDeckId = deckID;
        selectedDecks.push(extraDeck);
        console.log(selectedDecks);
        document.querySelector(".deckslist").innerHTML+=('<li '+' data-pos="'+selectedDecks.length+'"'+' data-deckId="'+deckID+'"'+'><img src="../images/card.png" alt="Deck">deck</li>')
        sendDeckToJava();
    }
}

function deleteDeck() {
    selectedDecks.splice(indexOfSelectedDeck, 1);
    console.log(selectedDecks);
    showDecks();
}
function editDeck() {
    //TODO

}

function showDecks() {
    document.querySelector(".deckslist").innerHTML=("<li class='newdeck selectedDeck deckInUse'>New deck</li>");
    for(let i=selectedDecks.length; i>0;i--){
        document.querySelector(".deckslist").innerHTML+=('<li '+' class="'+i+'"'+'><img src="../images/card.png" alt="deck">deck</li>')
    }
}

function switchClass() {
    switch(activeClass){
        case "mage":
            activeClass = "hunter";
            selectedDeck = null;
            decksMage = selectedDecks;
            selectedDecks = decksHunter;
            document.querySelector(".mage").classList.toggle("active");
            document.querySelector(".mage").classList.toggle("clickable");
            document.querySelector(".hunter").classList.toggle("active");
            document.querySelector(".hunter").classList.toggle("clickable");
            showDecks();
            break;
        case "hunter":
            activeClass = "mage";
            selectedDeck = null;
            decksHunter = selectedDecks;
            selectedDecks = decksMage;
            document.querySelector(".hunter").classList.toggle("active");
            document.querySelector(".hunter").classList.toggle("clickable");
            document.querySelector(".mage").classList.toggle("active");
            document.querySelector(".mage").classList.toggle("clickable");
            showDecks();
            break;
    }
}
function sendDeckToJava(){
    JSON = {'DeckID': selectedDeckId, 'GebruikerID':1, 'Class': activeClass, 'Deck Name': 'Test'};
    console.log(JSON);
    HTTPgetRequest("http://localhost:4242/decks/getDeck",JSON);
}







