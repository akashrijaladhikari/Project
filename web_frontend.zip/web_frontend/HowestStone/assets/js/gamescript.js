'use strict';
document.addEventListener("DOMContentLoaded", init);

let player = {hero:"", onTurn:true, availableMana:0, maxMana:0, hp:30, imgSrc:"", deck:null, onHand:null, onTable:null};
let opponent = {hero:"", onTurn:false, availableMana:0, maxMana:0, hp:30, imgSrc:"", deck:null, onHand:null, onTable:null};

const cards = Array.from(document.getElementsByClassName("card"));
cards.forEach(x => {
    x.addEventListener("drag", drag);
});

let user = document.cookie;

if (user === ""){
    window.open("login.html",'_self');
}

function init() {
    document.querySelector('.email').innerHTML = user;
    hardCodePlayers();
    initializeGame();
    randomStartPlayer();
    requests();
    playGame();
    document.querySelector(".playerField").addEventListener("dragover", allowDrop);
    document.querySelector(".playerField").addEventListener("drop", drop);
}

function initializeGame(){
    document.querySelector(".opponent-name").innerHTML += opponent.hero;
    document.getElementById("imgOpponent").innerHTML += "<img src= '../images/"+ opponent.imgSrc + "'>";
    document.querySelector(".opponentHealth").innerHTML += opponent.hp;
    document.querySelector(".opponentMana").innerHTML += opponent.availableMana + "/" + opponent.maxMana;
    document.querySelector(".playerMana").innerHTML += player.availableMana + "/" + player.maxMana;
    document.querySelector(".playerHealth").innerHTML += player.hp;
    document.getElementById("imgPlayer").innerHTML += "<img src= '../images/"+ player.imgSrc + "'>";
    document.querySelector(".player-name").innerHTML += player.hero;
}

function hardCodePlayers(){
    player.hero = "Hunter";
    player.imgSrc = "portrait_rexxar.png";
    opponent.hero = "Mage";
    opponent.imgSrc = "portrait_jaina.png"
}

function playGame() {
    document.querySelector(".endTurn").addEventListener('click', endTurn);
    document.querySelector(".ability").addEventListener('click', ability);
}

function randomStartPlayer() {
    let randomStarter = Math.floor(Math.random()* 2);
    if (randomStarter === 1){
        player.onTurn = true;
        opponent.onTurn = false;
    }
    else{
        opponent.onTurn = true;
        player.onTurn = false;
    }

}

function requests() {
    // if (player.onTurn === true){
    //     console.log("The player begins");
    //     player.maxMana = 1;
    //     player.availableMana = player.maxMana;
    //     document.querySelector(".playerMana").innerHTML = player.availableMana + "/" + player.maxMana;
    //     turnTimer();
    //
    // }
    // else {
    //     console.log("The opponent begins");
    //     opponent.maxMana = 1;
    //     opponent.availableMana = opponent.maxMana;
    //     document.querySelector(".opponentMana").innerHTML = opponent.availableMana + "/" + opponent.maxMana;
    //     aIturn();
    //     endTurn();
    // }
    let aiFinished = HTTPGetRequest("http://localhost:4242/game/getAIFinished");
    let plHand = HTTPGetRequest("http://localhost:4242/game/getPlayerHand");
    let playerCards = document.querySelector(".playerHand");
    // for(let i = 0; i<)
    let plMinions = HTTPGetRequest("http://localhost:4242/game/getPlayerMinions");
    let playerField = document.querySelector(".playerField");

    let aiMinions = HTTPGetRequest("http://localhost:4242/game/getAIMinions");
    let aiField = document.querySelector(".opponentField");

    while(!document.querySelector(".playerHealth").innerHTML==="0"||
    !document.querySelector(".opponentHealth").innerHTML==="0") {
        if(document.querySelector(".playerHealth").innerHTML==="0") {
          //todo defeat

            return;
        } else if (!document.querySelector(".opponentHealth").innerHTML==="0") {
            //victory

            return;
        }
        requests();
    }
}

function addCard() {

}

function addMinion() {

}

function endTurn() {
    HTTPGetRequest("http://localhost:4242/game/endTurn");
    // if (player.onTurn === true){
    //     player.onTurn = false;
    //     opponent.onTurn = true;
    //     console.log("opponent is on turn");
    //     if(opponent.maxMana <10){
    //         plusMaxmana();
    //         document.querySelector(".opponentMana").innerHTML = opponent.availableMana + "/" + opponent.maxMana;
    //     }
    //     regenMana();
    //     aIturn();
    //     document.querySelector(".opponentMana").innerHTML = opponent.availableMana + "/" + opponent.maxMana;
    //     endTurn();
    // }
    // else{
    //     player.onTurn = true;
    //     document.querySelector(".ability").addEventListener('click', ability);
    //     opponent.onTurn = false;
    //     console.log("player is on turn");
    //     if (player.maxMana < 10){
    //         plusMaxmana();
    //     }
    //     regenMana();
    //     document.querySelector(".playerMana").innerHTML = player.availableMana + "/" + player.maxMana;
    //     turnTimer();
    // }
}

function turnTimer() {
    console.log("Timer starts...")
    window.setTimeout(endTurn, 75000);
}


// <editor-fold desc ="Mana & damage"
function plusMaxmana() {
    if (player.onTurn === true) {
        console.log("player mana vermeerdert");
        player.maxMana += 1;
    }
    else {
        console.log("opponent mana vermeerdert");
        opponent.maxMana +=1;
    }
}

function regenMana() {
    if (player.onTurn===true) {
        console.log("player mana regent")
        player.availableMana = player.maxMana;
    }
    else {
        console.log("opponent mana regent")
        opponent.availableMana = opponent.maxMana;
    }
}

function subtractMana(amount, target) {
    target -= amount;
    if (player.onTurn === true){
        console.log("substract player mana");
        player.availableMana = target;
    }
    else{
        console.log("substract opponent mana");
        opponent.availableMana = target;
    }
    document.querySelector(".playerMana").innerHTML = player.availableMana + "/" + player.maxMana;
    document.querySelector(".opponentMana").innerHTML = opponent.availableMana + "/" + opponent.maxMana;
}

function damage(amount, target) {
    target -= amount;
    if (player.onTurn === true){
        opponent.hp = target;
    }
    else{
        player.hp = target;
    }

    document.querySelector(".opponentHealth").innerHTML = opponent.hp;
    document.querySelector(".playerHealth").innerHTML = player.hp;
    if (player.hp <= 0 || opponent.hp <= 0){
        document.querySelector('.victory').classList.toggle('hidden');
        document.querySelector(".victory").innerHTML += "<img src='../images/victory.png'><a href='mainMenu.html'>Continue ...</a>";
        document.querySelector('.battlefield').style.pointerEvents = "none";
        document.querySelector('.battlefield').style.opacity = "0.4";


    }
}
// </editor-fold>

// <editor-fold desc ="Ability"
function ability() {
    if (player.availableMana > 1) {
        console.log("ability macheert");
        switch (player.hero) {
            case "Mage":
                console.log("Zo ne grote vuurbal joenge");
                fireBall();
                break;
            case "Hunter":
                console.log("steady");
                steadyShot();
                break;
        }
    } else {
        alert("Not enough mana");
    }
}

//a mage's ability, fireball, deals 1 damage and costs 2 mana,
// to be used only once a turn
function fireBall() {
    if (player.onTurn === true) {
        subtractMana(2, player.availableMana);
        damage(1, opponent.hp);
        document.querySelector(".ability").removeEventListener("click", ability);
    } else {
        subtractMana(2, opponent.availableMana);
        damage(1, player.hp);
    }
}

//a hunter's ability, Steady Shot, deals 2 damage and costs 2 mana.
function steadyShot() {
    if (player.onTurn === true) {
        subtractMana(2, player.availableMana);
        damage(2, opponent.hp);
        document.querySelector(".ability").removeEventListener("click", ability);
    } else {
        subtractMana(2, opponent.availableMana);
        damage(2, player.hp);
    }
}
// </editor-fold>

// <editor-fold desc ="Settings"

function closeSettings() {
    console.log("closed");
    document.querySelector(".gameMenu").style.display = 'hidden';
}

function settings(e) {
    e.preventDefault();
    console.log("geklikt");
    this.disabled;
    document.querySelector(".hidden").className = "gameMenu";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

// </editor-fold>


//AI logic
function aIturn() {
    if (opponent.availableMana > 1) {
        switch (opponent.hero){
            case "Mage":
                console.log("AI attacks");
                fireBall();
                break;
            case "Hunter":
                steadyShot();
        }
    }
}
// Drag and Drop Cards
let dragTarget = null;

function allowDrop(e) {
    e.preventDefault();
}

function drag({e}) {
   dragTarget = this;
}
function drop(e) {
    e.preventDefault();
    e.currentTarget.appendChild(dragTarget);
    dragTarget = null;
}

//TEST
