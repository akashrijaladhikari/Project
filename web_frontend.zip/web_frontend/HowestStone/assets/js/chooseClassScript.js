'use strict';
document.addEventListener("DOMContentLoaded", init);

let chosenHeroPlayer;
let chosenHeroOpponent;
let user = document.cookie;

if (user === ""){
    window.open("login.html",'_self');
}

function init() {
    console.log(user);
    document.querySelector('.email').innerHTML = user;
    generateHero(inputGenerateHero());
    let open = document.querySelectorAll('.open');
    for (let i = 0; i < open.length; i++) {
        open[i].addEventListener('click',openHeroConfirmation);
    }
    /*
       document.getElementById('sideBar').onclick = function(e) {
           if(e.target != document.getElementById('sideBar')) {
               console.log('You clicked outside');
           } else {
               console.log('You clicked inside');
           }
       }
       */
    document.querySelector('.closeHeroConfirmation').addEventListener('click',closeHeroConfirmation);
    document.getElementById('confirmHero').addEventListener('click', confirmHeroPlayer);
    document.getElementById('confirmOpponent').addEventListener('click', confirmHeroOpponent);
}

// <editor-fold desc ="ChooseHero"

// html generate
function generateHero(heroes) {
    let text = "";
    for (let i = 0; i < heroes.length; i++) {
        text += "<li><img src='" + heroes[i].imgElement + "' class='open'" + "id='" +heroes[i].id+ "'><p>"+heroes[i].id+"</p></li>";

    }
    document.getElementById("heroes").innerHTML += text;
}

function inputGenerateHero() {
    let mage = {name: "Mage", imgElement: "../images/ChooseHero_Jaine.png", id: "Mage"};
    let hunter = {name: "Hunter", imgElement: "../images/ChooseHero_Rexxar.png", id: "Hunter"};
    let heroes = [hunter, mage];
    return heroes
}

// sidebar
function openHeroConfirmation(e) {
    document.getElementById("sideBar").style.width = "50%";
    document.getElementById('chosenHero').innerHTML += "<img src='"+e.target.src+ "' id ='"+ e.target.id + "' class='chosenHero'/>" ;
    document.getElementById('main').style.pointerEvents = "none";
    document.getElementById('main').style.opacity = "0.3";
    document.querySelector('.chosenHero').style.opacity = "1";
}

function closeHeroConfirmation(e) {
    document.getElementById("sideBar").style.width = "0";
    document.getElementById('main').style.pointerEvents = "auto";
    document.getElementById('main').style.opacity = "1";
    resetHeroConfirmation();
}

function resetHeroConfirmation() {
    document.getElementById("chosenHero").innerHTML = "";
}
// Confirmation
function confirmHeroPlayer() {
    chosenHeroPlayer = document.querySelector('.chosenHero').id;
    console.log("Chosen hero: " + chosenHeroPlayer);
    window.open('chooseOpponent.html', '_self')
}

function confirmHeroOpponent() {
    chosenHeroOpponent = document.querySelector('.chosenHero').id;
    console.log("Chosen opponent: " + chosenHeroOpponent);
    let data = {
        player: chosenHeroPlayer,
        opponent: chosenHeroOpponent,
        userID: 1
    };

    console.log(
        "sending through \"/game/confirmStartgame\" endpoint:" + data);
    HTTPPostRequest("/game/confirmStartgame", data);
}
// </editor-fold>
