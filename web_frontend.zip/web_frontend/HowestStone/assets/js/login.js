"use strict";
document.addEventListener("DOMContentLoaded",init);
function init(){
    document.querySelector(".login").addEventListener("click", login);
}
function login(e) {
    e.preventDefault();
    fetch("http://localhost:4242/user/login",{
        headers: new Headers({
            'Accept': 'application/json'
        })
    })
        .then(function (response) {
            if (response.status !== 200 ){
                throw "No response. fix it"
            }
            return response.json()
        })
        .then(function (data) {
            console.log(data);
            let APIemail = data.email;
            let APIpass = data.password;
            let email = document.getElementById('email').value;
            let pass = document.getElementById('password').value;
            if (APIemail !== email || APIpass !== pass){
                document.querySelector('.error').innerHTML = "<span>&#x26A0;</span> Email or Password is incorrect <span>&#x26A0;</span>";
                console.log('error');
            }else {
                //set email field in API.js to the one used to login
                setEmail(email);
                console.log('Logged on');
                document.querySelector('.error').innerHTML = "";
                document.cookie = APIemail;
                window.open("../pages/mainMenu.html","_self")
            }
            console.log(APIpass + " " + APIemail);
        })
        .catch(function (error) {
            console.log(error)
        })
}
