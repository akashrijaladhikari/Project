"use strict";
document.addEventListener("DOMContentLoaded", init);

let sum;
let gebruiker;
// after the page is fully loaded: do this
function init() {
    captcha();
    document.querySelector(".register").addEventListener("click", check);
}
function captcha(){
    let getal1 = Math.floor(Math.random() * 20) + 1;
    let getal2 = Math.floor(Math.random() * 20) + 1;
    sum = getal1 + getal2;
    console.log(sum);
    document.getElementById('sum').innerHTML = getal1 + " + " + getal2;
}
function check(e) {
    e.preventDefault();
    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let email2 = document.getElementById("email2").value;
    let password = document.getElementById("password").value;
    let password2 = document.getElementById("password2").value;
    if (email !== email2){
        alert("Your email doesn't match.");
        return false
    }
    if (password !== password2){
        alert("Password doesn't match. Please retype your password.");
        return false
    }
    let res = document.getElementById("captcha").value;
    console.log(res);
    if (parseInt(res) === sum){
        document.getElementById('sum').innerHTML = "Registerd";
    }else if(parseInt(res) !== sum){
        alert("U are a bot XO");
        captcha();
        document.getElementById("captcha").value = "";
        return false
    }
    gebruiker = {Naam: username, Email: email, Password: password};
    console.log(gebruiker);
    voegGebruikerToe();
    window.open("login.html","_self");
}
function voegGebruikerToe() {
    HTTPPostRequest("http://localhost:4242/user/register", gebruiker);
}
