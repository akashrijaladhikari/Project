//Created by Lev Pokazaniev on 5/7/2018.
"use strict";


//test:
// HTTPgetRequest("http://localhost:4242/game/getGameData");
// HTTPPostRequest("http://localhost:4242/game/JSToJava", {uniqueID:"TEST"});
// voegGebruikerToe();
// function voegGebruikerToe() {
//     let json = { cardID:"001", name: "fireball"};
//     HTTPPostRequest("http://localhost:4242/game/JSToJava", json);
// }

let mappedFunctions =
    {
        "requestOwnMinion":
        function () {
            //TODO: listeners for selecting a minion
            let json={uniqueID:""};
        }
    };

let email;

function setEmail(newEmail) {
    email=newEmail;
}

function HTTPGetRequest(path) {
    let request = {
        method: 'get',
        headers: new Headers({
            "Accept": "application/json"
            })
    };
    fetch(path, request)
        .then(function (res) {
            console.log(res);
            return res.json();
        })
        .then(function (json) {
            console.log(json);
            console.log("Succesfully received data");
        })
        .catch(function (error) {
            console.log(error);
        });
}
function HTTPPostRequest(path, data) {
    fetch(path,
        {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            method: "POST",
            body: JSON.stringify(data)
        })
        .then(function(res){ 
            console.log(res);
            return res.json();
        })
        .catch(function(data){
            console.log(JSON.stringify(data))
        });
}


