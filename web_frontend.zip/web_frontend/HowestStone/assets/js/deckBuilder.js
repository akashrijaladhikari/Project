'use strict';
document.addEventListener("DOMContentLoaded", loadJSON);

let cards = [];
let deck = [];
let deckName;

function loadJSON() {
    fetch("http://localhost:4242/game/getMinions",
        {
            headers: new Headers({
                "accept": "application/json",
            })
        })
        .then(function (response) {
            if (response.status !== 200) {
                throw ("help me");
            }
            return response.json();
        })
        .then(function (myJson) {
            cards = myJson;
            loadAllCards();
            document.querySelector('.cardslist').addEventListener('click', inDeck);
            document.querySelector('.decklist').addEventListener('click', outDeck);
            document.querySelector('.save').addEventListener('click', nameDeck);

        })
        .catch(function (error) {
            console.log(error);
        });
}

function loadAllCards() {
    document.querySelector('.cardslist').innerHTML='';
    for(let i=0;i<cards.length;i++){
        document.querySelector(".cardslist").innerHTML += '<li data-pos="'+i+'" class="card"><img src="'+ cards[i].img+'" alt="Card"></li>';
    }
}

function inDeck(e) {
    if(e.target.tagName.toLowerCase() === 'li'){
        let index = parseInt(e.target.getAttribute('data-pos'));
        deck.push(cards[index]);
        cards.splice(index,1);
        showDeck();
        loadAllCards();
    }
}

function outDeck(e) {
    if(e.target.tagName.toLowerCase() === 'li'){
        console.log(e.target.tagName.toLowerCase());
        console.log('lol');
        let index = parseInt(e.target.getAttribute('data-pos'));
        cards.push(deck[index]);
        deck.splice(index,1);
        showDeck();
        loadAllCards();
    }
}

function showDeck(){
    document.querySelector('.decklist').innerHTML='';
    for(let i=0;i<deck.length;i++) {
        document.querySelector('.decklist').innerHTML+= '<li data-pos="'+i+'" class="deckCard"><img src="'+ deck[i].img+'" alt="Card"></li>'
    }
}

function nameDeck(){
    deckName = document.querySelector('.deckName').value;
    console.log(deckName);
    document.querySelector('h2').innerHTML = deckName;
}