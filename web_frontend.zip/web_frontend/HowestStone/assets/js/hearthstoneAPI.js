"use strict";
document.addEventListener('DOMContentLoaded',init);

function init() {
    getCards();
}

function getCards() {
    fetch("http://localhost:63342/HowestStone/assets/js/minions.json?_ijt=6ue54o0nkdjde9m2p4cm871obf",
        {headers: new Headers({
            "accept": "application/json",
        })
        })
        .then(function(response) {
            if(response.status !== 200){
                throw ("help me");
            }
            return response.json();
        })
        .then(function(myJson) {
            console.log(myJson);

        })
        .catch(function (error) {
            console.log(error);
        });

}

function renderAllOnScreen(myJson) {
    let htmlString = "";
    for(let i=0; i< myJson.length; i++){
        htmlString += "<h1>"+i+"</h1>";
        //htmlString += "<img src='"+ myJson[i].img + "'>";
        htmlString += "<p>"+JSON.stringify(myJson[i])+"</p>";

    }
    document.querySelector(".wtf").innerHTML = htmlString;
}