"use strict";

document.addEventListener('DOMContentLoaded',init);

function init() {
    getHero(inputGetHero());
    victory(inputVictory());
}

function getHero(hero) {
    document.getElementById("nameHero").innerHTML += hero.name;
    document.querySelector("main").innerHTML += "<img src='"+ hero.imgElement + "'>"
}

function victory(victory) {
    if (victory === true){
        document.getElementById("status").innerHTML += "Victory!";
    }
    else{
        document.getElementById("status").innerHTML += "Defeat!";
    }

}

function inputGetHero(){
    return {name: "Mage", imgElement: "images/Jaina_Proudmoore.png"};
}

function inputVictory() {
    return false;
}
