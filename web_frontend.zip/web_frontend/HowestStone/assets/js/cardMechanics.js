
'use strict';
document.addEventListener("DOMContentLoaded", init);

function init() {
    loadJSON();
}

function loadJSON() {
    fetch("../assets/js/cards.json", {
        method : "get"
    })
        .then(function (response) {
            return response.json();
        })
        .then(function (myjson) {
            console.log(myjson);
            cardsMagic(myjson);
        })
        .catch(function (error) {
            console.log(error);
        });
}

function cardsMagic(cards){
    let mageCards = cards.Mage;
    mageCards = shuffle(mageCards);
    console.log(mageCards);
}


function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}



function putCardsInHand(amountOfCards, deck) {
    let cardsInHand =[];
    for(let i=0; i < amountOfCards; i++){
        cardsInHand.push(deck[i]);
        delete deck[i];
    }
    console.log(deck);
    console.log(cardsInHand);
    //document.querySelector(".wtf").innerHTML += "<img src='" + cardsInHand.img + "'>";

}

function printCardsImages(cards) {
    for (let i = 0; i < 3; i++){
        document.querySelector(".wtf").innerHTML += "<img src='" + cards[i].img + "'>";
    }

}
// DECKBUILDER?

function giveAmountOfCardsAtStart() {
    let playerStartAmount;
    if (!test) {
        // TODO: Getting the used deck from deckBuilder.js with function deckBuilder.getDeck()
        //playerDeck=deckBuilder.getDeck();
        //playerDeck=getDeck(playerDeck);

        // TODO: Getting Basic cardSet from API with function API.etBasicCardSet()
        //API.js (connector class between Java and js) to include function getBasicCardSet() that will return the basic cardSet from the database
        //cardSet variable is required to create a random deck for the AI
        //cardSet= API.getBasicCardSet();

        //TODO: function gameScript.getStartingPlayer() which will return starting player's object
        //if startingPlayer() returns the player, draw 3 cards, else (returns opponent) draw 4 cards:
        //playerStartAmount=(gameScript.getStartingPlayer()===gameScript.player) ? 3 : 4;

    } else {
        let playerDeck;
        //TESTING: assigning static cardSet

        //TESTING WITH PLAYER STARTING
        playerStartAmount = 3;
        playerDeck = getDeck(cardSet);
        player={deck: playerDeck, hand: [], role: "attacker"}

    }   //TEST END
}

function getCard(deck) {
    let data;
    if (!test) {
        //TODO: get card data from API
        data=randomElementFromArray(deck);
    } else {//TEST
        data=randomElementFromArray(cardSet);
    }//TEST END

    return new Card(data);
}

//Returns random element from array;
function randomElementFromArray(a) {
    return a[Math.floor(Math.random() * a.length)];
}
