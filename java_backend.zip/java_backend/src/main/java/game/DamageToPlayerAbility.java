package game;

/**
 * Created by Lev Pokazaniev on 2/05/2018.
 */
public class DamageToPlayerAbility extends DamageAbility {

    private static final String TYPE = "DamageToPlayerAbility";

    public DamageToPlayerAbility(int damage){
        super(damage);
        setActivateOnPlay(true);
    }

    @Override
    public void ability() {
        if(!isUsed()) {
                GameAppConsole.getGame().getOpponent().takeDamage(getDamage());
                toggleUsed();
        } else {
            System.out.println("Hero ability has already been used this turn.");
        }
    }
}
