package game;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Card implements Comparable {
    private String cardId;
    private int dbfId;
    private String name;
    private String type;
    private int cost;
    private int attack;
    private int health;
    private String img;
    private Mechanics mechanics;
    private ArrayList<Ability> abilities;
    private String uniqueID;

    public Card(String cardId, String dbfId, String name, String type, int cost, int attack, int health, String img){
        this.cardId = cardId;
        this.dbfId = Integer.parseInt(dbfId);
        this.name = name;
        this.type = type;
        this.cost = cost;
        this.attack = attack;
        this.health = health;
        this.img = img;
        this.abilities = DataBaseConnector.getAbilities(cardId);
        this.uniqueID="cardid" + GameLogic.getNextID();
    }

    public String getUniqueID() {
        return uniqueID;
    }

    //Defines comparable for usage in sorting (ascending order by mana cost)
    @Override
    public int compareTo(@NotNull Object cards1) {
        int compareCost=((Card)cards1).getCost();
        return this.cost-compareCost;
    }

    //Decides chain of events when a card of a certain type has been played.
    public void playCard(Player player) {
        //TODO: fix battlecry so it would affect ne minions as well
        if(player.enoughMana(cost)) {
            player.substractMana(cost);
            for (Ability ability : abilities) {
                if (ability.activatedOnPlay()) ability.ability();
            }
            switch (type) {
                case "Minion":
                    player.addMinion(this);
                    break;
                case "Spell":
                    break;
            }
            player.getOnHand().deleteCard(this);
            player.getOnTable().addCard(this);
        }
    }

    public void substractHealth(int amount){
        health = health-amount;
    }

    public String getCardId() {
        return cardId;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getCost() {
        return cost;
    }

    public int getAttack() {
        return attack;
    }

    public String getImg() {
        return img;
    }

    public Mechanics getMechanics() {
        return mechanics;
    }

    public int getHealth() {
        return health;
    }

    public ArrayList<Ability> getAbilities() {
        return abilities;
    }

}
