package game;

public class Mechanics {
}
