package game;

/**
 * Created by Lev Pokazaniev on 16/05/2018.
 */
public class WindfuryAbility extends Ability {
    private boolean hasTarget;
    public WindfuryAbility(Actor owner, boolean activateOnPlay, boolean hasTarget) {
        super(owner);
        this.setActivateOnPlay(activateOnPlay);
        this.hasTarget=hasTarget;
        if(activateOnPlay) ability();

    }

    @Override
    public void ability(){
        Minion target;
        if(hasTarget) {
            target = GameLogic.requestOwnTargetMinion();

        }
        target=(Minion)getOwner();
        ability(target);

    }

    @Override
    public void ability(Minion target) {
        target.setTookTurn(false);
    }
}
