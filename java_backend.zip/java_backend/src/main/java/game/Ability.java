package game;

/**
 * Created by Lev Pokazaniev on 26/04/2018.
 */
public class Ability {

    private boolean used;

    private static final String TYPE = "Ability";

    private boolean activateOnPlay;

    private Actor owner;

    public Ability(Actor owner) {
        this.used = false;
        this.activateOnPlay = false;
        this.owner=owner;
    }

    public Ability() {
        this.used = false;
        this.activateOnPlay = false;
    }

    public boolean isUsed() {
        return used;
    }

    public void toggleUsed() {
        this.used = !this.used;
    }

    public void ability() {
        if (!used) toggleUsed();
    }

    public static String getTYPE() {
        return TYPE;
    }

    public boolean activatedOnPlay() {
        return activateOnPlay;
    }

    public void setActivateOnPlay(boolean activateOnPlay) {
        this.activateOnPlay = activateOnPlay;
    }


    public Actor getOwner() {
        return owner;
    }

    public void disableAbility() {}

    public boolean isOfTYPE(String battlecryAbility) {
        return battlecryAbility.equals(TYPE);
    }

    public void ability(Minion target) {}
}
