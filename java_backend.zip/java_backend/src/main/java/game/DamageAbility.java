package game;

import java.util.ArrayList;

/**
 * Created by Lev Pokazaniev on 26/04/2018.
 */
public class DamageAbility extends Ability {

    private int damage;

    private static final String TYPE = "DamageAbility";

    public DamageAbility(int damage) {
        super();
        this.damage = damage;
        setActivateOnPlay(true);
    }

    @Override
    public void ability() {
        Actor target = GameLogic.requestEnemyTargetMinionOrPlayer();
        if(!isUsed()) {
            target.takeDamage(damage);
            toggleUsed();
        } else {
            System.out.println("Hero ability has already been used this turn.");
        }
    }

    public int getDamage() {
        return damage;
    }

}
