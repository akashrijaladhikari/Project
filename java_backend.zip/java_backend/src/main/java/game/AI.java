package game;

import java.util.ArrayList;

/**
 * Created by Lev Pokazaniev on 2/05/2018.
 */
public final class AI {

    public static boolean isFinished() {
        return finished;
    }

    private static Player ai;
    private static Player human;
    private static boolean finished = human.getIsOnTurn();


    public static void AITurn() {
        finished = false;
        ai.getDeck().dealCards(1);
        ai = Game.getActivePlayer();
        human = Game.getOpponent();
        if (!ai.getMinions().isEmpty()) useMinions();
        if (!ai.getOnHand().getCards().isEmpty()) playCards();
        if (ai.getHeroAbility().getClass() == DamageToPlayerAbility.class && !GameLogic.enemyHasTaunt()) {
            ai.useHeroAbiltiy();
        } else if (ai.getHeroAbility().getClass() == DamageAbility.class && !GameLogic.enemyHasTaunt()) {
            ai.useHeroAbiltiy();
        } else {
            ai.useHeroAbiltiy();
        }
        Game.takePlayerTurn();
        finished = true;
        human.getDeck().dealCards(1);
    }

    //AI using its minions
    private static void useMinions() {
        ArrayList<Minion> minions = ai.getMinions();
        for (Minion minion : minions) {
            if (minion.tookTurn()) continue;
            ArrayList<Minion> enemyMinions = human.getMinions();
            if (!enemyMinions.isEmpty()) {
                Actor target;
                if (GameLogic.enemyHasTaunt()) {
                    target = chooseEnemyMinionWithTaunt();
                } else {
                    target = chooseEnemyMinionOrPlayer();
                }
                minion.attack(target);
            } else {
                minion.attack(human);
            }
        }
    }

    //Playing card from hand
    private static void playCards() {
        ArrayList<Card> hand = ai.getOnHand().getCards();
        if (hand.isEmpty()) return;
        int availableMana = ai.getAvailableMana();
        int index = hand.size() - 1;
        while (hand.get(index).getCost() > availableMana) {
            index--;
            if (index == -1) {
                System.out.println("No playable cards for AI.");
                return;
            }
        }
        hand.get(index).playCard(ai);
        playCards();
    }

//    //Playing free cards
//    public void playFreeCards() {
//        Cards hand = ai.getOnHand();
//        Cards board = ai.getOnTable();
//        ArrayList<Card> freeCards = hand.getFreeCards();
//        for (Card freeCard : freeCards) {
//            hand.deleteCard(freeCard);
//            freeCard.playCard(player);
//        }
//    }

    //Selecting an enemy to target
    public static Actor chooseEnemyMinionOrPlayer() {
        ArrayList<Minion> minions = GameLogic.getPossibleEnemyMinionTargets();
        if (minions.isEmpty()) return human;
        return GameLogic.randomEnemyActor(minions, human);
    }

    public static Minion chooseEnemyMinion() {
        ArrayList<Minion> minions = GameLogic.getPossibleEnemyMinionTargets();
        if (minions.isEmpty()) return null;
        return GameLogic.randomMinion(minions);
    }

    private static Actor chooseEnemyMinionWithTaunt() {
        ArrayList<Minion> minionsWithTaunt = GameLogic.getEnemyMinionsWithTaunt();
        return GameLogic.randomEnemyActor(minionsWithTaunt, null);
    }

    //Selecting a minion from own board
    public static Actor chooseMinionOrPlayer() {
        ArrayList<Minion> minions = ai.getMinions();
        return GameLogic.randomEnemyActor(minions, ai);
    }

    public static Minion chooseMinion() {
        ArrayList<Minion> minions = ai.getMinions();
        return GameLogic.randomMinion(minions);
    }

    public static Minion chooseMinionWithoutShield() {
        return GameLogic.randomMinion(ai.getMinionsWithoutShield());
    }
}
