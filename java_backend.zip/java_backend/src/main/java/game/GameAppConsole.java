package game;

public class GameAppConsole {
    private static Game game;

    public static void main(String[] args) {
        Game.createDecks();
    }
    public static void setGame(Game newGame) {
        game=newGame;
    }

    public static Game getGame() {
        return game;
    }
}
