package game;

import java.util.ArrayList;

/**
 * Created by Lev Pokazaniev on 8/05/2018.
 */
public class BattlecryOnAllAbility extends BattlecryAbility {
    private static final String TYPE = "BattlecryAbility";
    public BattlecryOnAllAbility(int amountOfHp, Actor owner) {
        super(amountOfHp, owner);
    }
    private ArrayList<Minion> targets;

    @Override
    public void ability() {
        if(Game.getActivePlayer().getMinions().isEmpty()) return;
        targets = Game.getActivePlayer().getMinions();
        for(Minion target : targets) {
            target.addToActualHP(getAmountOfHp());
            target.addActiveBattlecry(this);
        }
    }

    @Override
    public void disableAbility() {
        for(Minion target: targets) {
            target.removeActiveBattlecry(this);
            target.subtractFromActualHP(getAmountOfHp());
        }
    }
}
