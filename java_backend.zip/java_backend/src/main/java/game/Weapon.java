package game;

/**
 * Created by Lev Pokazaniev on 16/05/2018.
 */
public class Weapon {
}
