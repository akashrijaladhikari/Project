package game;

/**
 * Created by Lev Pokazaniev on 26/04/2018.
 */
public class Actor {
    int maxHp;
    int hp;
    private boolean alive;
    boolean tookTurn;
    private String uniqueID;
    String name;
    int attack;

    public Actor() {
        this.alive = true;
        this.uniqueID = "actorid" + GameLogic.getNextID();
        this.tookTurn = false;
    }

    public String getName() {
        return name;
    }

    int getHP() {
        return hp;
    }

    void setHP(int hp) {
        this.hp = hp;
    }

    String getUniqueID() {
        return uniqueID;
    }

    boolean tookTurn() {
        return tookTurn;
    }

    void setAlive(boolean alive) {
        this.alive = alive;
    }

    boolean isAlive() {
        return alive;
    }

    public void kill() {
        this.setAlive(false);
    }

    public void takeDamage(int damage) {
        hp=hp-damage;
    }

    int getAttack() {
        return attack;
    }

    public void attack(Actor target) {
    }
}
