package game;

/**
 * Created by Lev Pokazaniev on 24/05/2018.
 */
public class Collection {
}
