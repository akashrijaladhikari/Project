package game;

import java.util.ArrayList;

/**
 * Created by Lev Pokazaniev on 26/04/2018.
 */

public class Minion extends Actor {
    private Player owner;
    private boolean taunt;
    private boolean divineShield;
    private ArrayList<BattlecryAbility> battlecries = new ArrayList<>();
	private int actualHP;
	private boolean hasBattlecryAbility;
	private Ability battlecryAbility;
	private boolean hasActiveBattlecry;
    private int attack;
    private String name;
    private ArrayList<Ability> abilities;
    private int attacksDone;

    public Minion(Card card, Player owner) {
        this.owner = owner;
        this.taunt = false;
        this.maxHp=card.getHealth();
        this.hp=this.maxHp;
        this.name=card.getName();
        this.attack=card.getAttack();
		this.actualHP=getHP();
        this.hasBattlecryAbility=hasBattlecryAbility();
        this.hasActiveBattlecry=false;
        this.abilities=DataBaseConnector.getAbilities(card.getCardId());
    }

     boolean hasTaunt() {
        return taunt;
    }

    public void setTaunt(boolean taunt) {
        this.taunt = taunt;
    }

     void setTookTurn(boolean tookTurn) {
        if (tookTurn && getAttacksDone() > 1) return;
        this.tookTurn = tookTurn;
    }

    public void kill() {
		if (hasShield()) {
			divineShield=false;
			return;
		}
		disableBattlecryAbilityEffects();
        this.setAlive(false);
        owner.discardMinion(this);
    }

    private void disableBattlecryAbilityEffects() {
        if(hasBattlecryAbility()){
            battlecryAbility.disableAbility();
        }
    }

    private boolean hasBattlecryAbility() {
        if(getAbilities().isEmpty()) return false;
        boolean hasBattlecry=false;
        int index = 0;
        Ability ability = getAbilities().get(index);
        while(index<getAbilities().size()&&!ability.isOfTYPE("BattlecryAbility")) {
            ability = getAbilities().get(index);
            if(ability.isOfTYPE("BattlecryAbility")) {
                hasBattlecry=true;
                battlecryAbility=ability;
            }
            index++;
        }
        return hasBattlecry;
    }

    private void checkForActiveBattlecries() {
        if(battlecries.isEmpty()){
            hasActiveBattlecry=false;
        }
    }

     boolean hasShield() {
        return divineShield;
    }

     void activateDivineShield() {
        divineShield= true;
    }

	 void addToActualHP(int hpToAdd) {
		actualHP+=hpToAdd;
	}

     void addActiveBattlecry(BattlecryAbility battlecryAbility) {
        hasActiveBattlecry=true;
        battlecries.add(battlecryAbility);
    }

     void removeActiveBattlecry(BattlecryAbility battlecryAbility) {
        battlecries.remove(battlecryAbility);
        checkForActiveBattlecries();
    }

     void subtractFromActualHP(int amountOfHp) {
        actualHP = (actualHP-amountOfHp>0) ? actualHP-amountOfHp : 1;
    }

     private ArrayList<Ability> getAbilities() {
        return abilities;
    }

    public void attack(Actor target) {
        addAttackDone();
        setTookTurn(true);
        if (attack > 0) {
            if (target.getClass() == Minion.class) {
                this.takeDamage(target.getAttack());
            }
            target.takeDamage(getAttack());
        }
    }

    @Override
    public void takeDamage(int damage) {
        if (actualHP - damage > 0) {
            System.out.println("Damage dealt to " + this.name);
            actualHP=actualHP-damage;
            setHP(hp-damage);
        } else {
            System.out.println("killed " + this.name);
            kill();
        }
    }


    private int getAttacksDone() {
        return attacksDone;
    }

    private void addAttackDone() {
        attacksDone++;
    }

}
