package game;

import java.util.Random;

/**
 * Created by Lev Pokazaniev on 26/04/2018.
 */
public class DrawCardsAbility extends Ability {

    private int amount;

    private static final String TYPE = "DrawCardsAbility";

    public DrawCardsAbility(int amount){
        super();
        this.amount=amount;
        setActivateOnPlay(true);
    }

    @Override
    public void ability() {
        Player p = Game.getActivePlayer();
        p.getDeck().dealCards(amount);
    }
}
