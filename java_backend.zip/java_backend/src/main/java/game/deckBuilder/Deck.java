package game.deckBuilder;

public class Deck {

    private int id;
    private String naam;

    public Deck(int id, String naam) {
        this.id = id;
        this.naam = naam;
    }

    public int getId() {
        return id;
    }

    public String getNaam() {
        return naam;
    }
}
