package game.deckBuilder;

import game.Cards;

import java.util.ArrayList;

public class DeckBuilder {
    ArrayList<Cards> decksMage = new ArrayList<>();
    ArrayList<Cards> decksHunter = new ArrayList<>();

    public void refreshDecks(ArrayList<Cards> decks, String target){
        switch (target){
            case "hunter":
                decksMage = decks;
                break;
            case "mage":
                decksHunter = decks;
        }
    }

    public ArrayList<Cards> getFromJavascript(ArrayList<Cards> De_Shit_Die_Ik_Van_js_krijg){

        ArrayList<Cards> decks = De_Shit_Die_Ik_Van_js_krijg;
        return decks;
    }

    public void dezeShitWilIkNaarDeDBSturen(){
        //TODO stuur decksmage en decksHunter naar db

    }
}
