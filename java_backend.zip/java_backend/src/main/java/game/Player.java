package game;

import api.GameApp;

import java.util.ArrayList;

public class Player extends Actor {
    private boolean onTurn;
    private int availableMana;
    private int maxMana=1;
    private Cards deck;
    private Cards onHand;
    private Cards onTable;
    private ArrayList<Minion> minions = new ArrayList<>();
    private Ability heroAbility;
    private Weapon weapon;

    public Player(String heroID, boolean onTurn, Cards deck) {
        super();
        this.maxHp=30;
        this.hp=this.maxHp;
        this.name=heroID;

        heroAbility=
                (heroID.equals("Mage"))
                        ? new DamageAbility(1)
                        : new DamageToPlayerAbility(2)
        ;

        this.name=
                (heroID.equals("Mage"))
                        ? "Jaina Proudmoore"
                        : "Rexxar"
        ;

        this.onTurn = onTurn;
        this.availableMana = 1;
        this.deck = deck;
    }

    void setDeck(Cards deck) {
        this.deck = deck;
    }

    boolean getIsOnTurn() {
        return onTurn;
    }

     Cards getDeck() {
        return deck;
    }

    public Cards getOnHand() {
        return onHand;
    }

     Cards getOnTable() {
        return onTable;
    }


    public void setOnHand(Cards onHand) {
        this.onHand = onHand;
    }

    public void setOnTable(Cards onTable) {
        this.onTable = onTable;
    }

     void setOnTurn(boolean onTurn) {
        this.onTurn = onTurn;
    }


     void plusMaxMana() {
        if (maxMana < 10) {
            maxMana += 1;
        }
    }

     void regenMana() {
        availableMana = maxMana;
    }

     void substractMana(int amount) {
        availableMana -= amount;
    }

    public void damage(int amount) {
        hp -= amount;
        if (hp <= 0) {
            //TODO stop game go to victory
            Game.finish();
        }
    }

    public ArrayList<Minion> getMinions() {
        return minions;
    }

     void addMinion(Card card) {
        this.minions.add(new Minion(card, this));
    }

     Ability getHeroAbility() {
        return heroAbility;
    }

     int getAvailableMana() {
        return availableMana;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public boolean hasWeapon() {
        return this.weapon != null;
    }

     void useHeroAbiltiy() {
        if (!heroAbility.isUsed()) {
            if (availableMana >= 2) {
                heroAbility.ability();
                substractMana(2);
            } else {
                String message = "Hero " + name + " has not enough mana to use its ability.";
                GameApp.executeJavascriptFunction
                        (
                                GameApp.arrayToJSON(new String[] {getUniqueID(), message}),
                                "alertInsufficientManaForAbility"
                        );
            }
        }
    }

    @Override
    public void kill() {
        this.setAlive(false);
        GameAppConsole.getGame().endGame();
    }

     void discardMinion(Minion minion) {
        this.minions.remove(minion);
    }

     boolean enoughMana(int cost) {
        return availableMana >= cost;
    }
	
	 ArrayList<Minion> getMinionsWithoutShield() {
		ArrayList<Minion> minionsWithoutShield = new ArrayList<>();
		for(Minion minion : getMinions()) {
			if(minion.hasShield()) minionsWithoutShield.add(minion);
		}
		return minionsWithoutShield;
	}

    public boolean hasMinions() {
        return !minions.isEmpty();
    }

    boolean hasMinionsWithoutShield() {
        return !getMinionsWithoutShield().isEmpty();
    }

    @Override
    public void takeDamage(int damage) {
        if (hp - damage > 0) {
            System.out.println("Damage dealt to " + name);
            setHP(hp - damage);
        } else {
            System.out.println("killed " + name);
            kill();
        }
    }
}
