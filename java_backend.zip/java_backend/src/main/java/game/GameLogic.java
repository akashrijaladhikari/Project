package game;

import api.GameApp;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Lev Pokazaniev on 8/05/2018.
 */
public class GameLogic {

    private static Game game;
    private static Player human;
    private static Player ai;
    private static Random random;
    private static int currentID;

    public GameLogic() {
        game = GameAppConsole.getGame();
        human = game.getHuman();
        ai = game.getAI();
        random = new Random();
        currentID = 0;
    }

    public static boolean randomBoolean() {
        return random.nextBoolean();
    }

    private static boolean aiTurn() {
        return game.getActivePlayer() == ai;
    }

    //Checks if any of the enemy minions have taunt
    public static boolean enemyHasTaunt() {
        Player opponent = game.getOpponent();
        ArrayList<Minion> enemyMinions = opponent.getMinions();
        boolean enemyHasTaunt = false;
        int index = 0;
        while (!enemyHasTaunt && index < enemyMinions.size()) {
            if (enemyMinions.get(index).hasTaunt()) enemyHasTaunt = true;
        }
        return enemyHasTaunt;
    }

    //Choosing a card from a set of Cards
    public static Card randomCard(Cards cards) {
        int index = (random.nextInt(cards.getCards().size()));
        return cards.getCards().get(index);
    }

    //Returns a randomly selected target Actor
    public static Actor randomEnemyActor(ArrayList<Minion> options, Player player) {
        if (options.isEmpty()) return player;
        int index = (player != null) ? random.nextInt(options.size() + 1) : random.nextInt(options.size());
        return (index < options.size()) ? options.get(index) : player;
    }

    public static Minion randomMinion(ArrayList<Minion> minions) {
        int index = random.nextInt(minions.size());
        return minions.get(index);
    }


    //TODO: send request to js to display message, animation, (play sound) for two next methods
    private static void alertAboutZeroAttack(Actor actor) {
        String[] parameters = new String[2];
        parameters[0] = actor.getUniqueID();
        parameters[1] = "Your " +
                actor.getName() +
                " minion cannot attack as it is to weak to do so.";
        String json = GameApp.arrayToJSON(parameters);


        GameApp.executeJavascriptFunction
                (

                        json,
                        "alertZeroAttack"
                );
    }


    private static void alertAboutTurnTaken(Actor actor) {
        String[] parameters = new String[2];
        parameters[0] = actor.getUniqueID();
        parameters[1] = "Your " + actor.getName() +
                " minion cannot act now, let it rest until next turn.";
        String json = GameApp.arrayToJSON(parameters);

        GameApp.executeJavascriptFunction
                (

                        json,
                        "alertTurnTaken"
                );
    }

    //When a card has been clicked
    public static void tryToPlayCard(String uniqueID) {
        //TODO: call this function from js when a card has been clicked, zoomed in and clicked again
        Game.getCardFromMap(uniqueID).playCard(human);
    }

    //when a minion or your hero has been clicked
    public static void tryToUseMinion(String uniqueID) {
        //TODO: call this function from js with parameter being :
        //of Minion type if it was a minion
        //of Player type if it was your hero's ability that had been clicked
        Actor actor = Game.getMinionFromMap(uniqueID);
        if (actor.tookTurn()) {
            alertAboutTurnTaken(actor);
        } else if (actor.getAttack() == 0) {
            alertAboutZeroAttack(actor);
        } else {
            Actor target = requestEnemyTargetMinionOrPlayer();
            actor.attack(target);
        }
    }

    public static Minion requestOwnTargetMinion() {
        if (aiTurn()) return AI.chooseMinion();
        //TODO: send possible targets to js
        ArrayList<Minion> possibleTargets = game.getActivePlayer().getMinions();
        //TODO: send request to js get a target minion
        Minion target = possibleTargets.get(0);
        return target;
    }

    public static Actor requestOwnTargetMinionOrPlayer() {
        if (aiTurn()) return AI.chooseMinionOrPlayer();
        //TODO: send possible targets to js
        ArrayList<Minion> possibleTargets = game.getOpponent().getMinions();
        //TODO: send request to js get a target minion
        Minion target = possibleTargets.get(0);
        return target;
    }

    //Asking for an own target minion without Divine Shiel
    public static Minion requestOwnTargetMinionWithoutShield() {
        if (aiTurn()) return AI.chooseMinionWithoutShield();
        ArrayList<Minion> minionsWithoutShield = game.getActivePlayer().getMinionsWithoutShield();
        String json = GameApp.minionArrayListToJSONArray(minionsWithoutShield);
        return GameApp.requestMinionFromJS
                (

                        json,
                        "requestOwnTargetMinionWithoutShield"

                );
    }


    //Asking for an enemy target minioon
    public static Minion requestEnemyTargetMinion() {
        if (aiTurn()) return AI.chooseEnemyMinion();
        //TODO: send possible targets to js
        ArrayList<Minion> possibleTargets = getPossibleEnemyMinionTargets();
        //TODO: send request to js get a target minion
        Minion target = possibleTargets.get(0);
        return target;
    }

    public static Actor requestEnemyTargetMinionOrPlayer() {
        if (aiTurn()) return AI.chooseEnemyMinionOrPlayer();
        if (enemyHasTaunt()) return requestEnemyTargetMinion();
        //TODO: send possible targets to js
        ArrayList<Minion> possibleTargets = getPossibleEnemyMinionTargets();
        //TODO: send request to js get a target minion
        Minion target = possibleTargets.get(0);
        return target;
    }

    public static ArrayList<Minion> getPossibleEnemyMinionTargets() {
        if (enemyHasTaunt()) {
            return getEnemyMinionsWithTaunt();
        }
        return game.getOpponent().getMinions();
    }

    public static ArrayList<Minion> getEnemyMinionsWithTaunt() {
        ArrayList<Minion> minionsWithTaunt = new ArrayList<>();
        for (Minion minion : game.getOpponent().getMinions()) {
            if (minion.hasTaunt()) minionsWithTaunt.add(minion);
        }
        return minionsWithTaunt;
    }

    public static int getNextID() {
        int id = currentID;
        currentID++;
        return id;
    }


}
