package game;

import jdk.nashorn.internal.parser.JSONParser;

public class Login{
    private String email;
    private String password;
    private JSONParser savedJSON;
    private static int userID;

    public static int getUserID() {
        return userID;
    }

    public static void setUserID(int userID) {
        Login.userID = userID;
    }

    public Login(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public Login(String email, String password, JSONParser savedJSON) {
        this.email = email;
        this.password = password;
        this.savedJSON = savedJSON;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public JSONParser getSavedJSON() {
        return savedJSON;
    }
}
