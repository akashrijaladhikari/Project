package game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Cards {

    private ArrayList<Card> cards = new ArrayList<>();

    private Player owner;

    public Cards(Player owner){
        this.owner=owner;
}
    public void addCard(String cardId, String name, String dbfId, String type, int cost, int attack, int health, String img) {
        Card card = new Card(cardId, name, dbfId, type, cost, attack, health, img);
        cards.add(card);
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public void deleteCard(Card card) {
        cards.remove(card);
    }

    public void shuffle() {
        Collections.shuffle(cards);
    }

    public boolean inCards(Card card) {
        return cards.contains(card);
    }

    //Sorts cards by mana cost in ascending order
    public void sortByManaAscending() {
        if(!cards.isEmpty()) {
            Collections.sort(cards);
        }
    }

    //Returns a list of cards with a mana cost of 0
    public ArrayList<Card> getFreeCards() {
        ArrayList<Card> freeCards = new ArrayList<>();
        sortByManaAscending();
        if(!cards.isEmpty()) {
            int index = 0;
            int cost = cards.get(index).getCost();
            while (cost==0) {
                freeCards.add(cards.get(index));
                index++;
                cost = cards.get(index).getCost();
            }
        }
        return freeCards;
    }

    public ArrayList<Card> getCards() {
        return cards;
    }

    public void dealCards(int amount) {
        if(owner.getDeck().getCards().isEmpty()) return;

        Cards hand = owner.getOnHand();
        Cards deck = owner.getDeck();

        for (int i = 0; i < amount; i++) {
            if(hand.getCards().size()<10){
                hand.getCards().add(deck.getCards().get(0));
            }
            deck.getCards().remove(0);
        }
    }
}

