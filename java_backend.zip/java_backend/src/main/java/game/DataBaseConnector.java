package game;

import java.util.ArrayList;

/**
 * Created by Lev Pokazaniev on 5/05/2018.
 */
public class DataBaseConnector {

    //TODO: query database for abilities of a card with particular cardId
    public static ArrayList<Ability> getAbilities(String cardId) {
        ArrayList<Ability> abilities = new ArrayList<>();

        return abilities;
    }
}
