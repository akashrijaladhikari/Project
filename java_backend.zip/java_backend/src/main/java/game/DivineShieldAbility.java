package game;

/**
 * Created by Lev Pokazaniev on 9/05/2018.
 */
public class DivineShieldAbility extends Ability {
    public DivineShieldAbility(Actor owner) {
        super(owner);
        this.setActivateOnPlay(true);
    }
    @Override
    public void ability(){
        Player activePlayer = Game.getActivePlayer();
        if(activePlayer.hasMinionsWithoutShield()) {
            Minion target = GameLogic.requestOwnTargetMinionWithoutShield();
            target.activateDivineShield();
        }
    }
}
