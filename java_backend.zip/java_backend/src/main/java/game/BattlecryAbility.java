package game;

/**
 * Created by Lev Pokazaniev on 8/05/2018.
 */
public class BattlecryAbility extends Ability{
    private int amountOfHp;
    private static final String TYPE = "BattlecryAbility";
    private Minion target;

    public BattlecryAbility(int amountOfHp, Actor owner) {
        super(owner);
        this.amountOfHp=amountOfHp;
        this.setActivateOnPlay(true);
    }

    public int getAmountOfHp() {
        return amountOfHp;
    }

    @Override
    public void ability() {
        target = GameLogic.requestOwnTargetMinion();
        target.addActiveBattlecry(this);
        target.addToActualHP(amountOfHp);
    }

    @Override
    public void disableAbility() {
        target.removeActiveBattlecry(this);
        target.subtractFromActualHP(getAmountOfHp());
    }
}
