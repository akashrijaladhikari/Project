package game;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public final class Game {
    private static Player ai;



    private static Player player;
    private static int userID;
    private static HashMap<String, Card> cardMap = new HashMap<>();
    private static HashMap<String, Minion> minionMap = new HashMap<>();
    private static ObjectMapper mapper = new ObjectMapper();
    private static boolean finished = false;

    public Game (Player newAi, Player newPlayer, int newUserID) {
        ai = newAi;
        player=newPlayer;
        ai.plusMaxMana();
        ai.regenMana();
        userID=newUserID;
        start();

    }

    public static boolean isFinished() {
        return finished;
    }

    public static Player getAi() {
        return ai;
    }

    public static Player getPlayer() {
        return player;
    }

    public static void finish() {
        finished=true;
    }

    public void start() {
        createDecks();
        Player active = getActivePlayer();
        dealStartingCards();

        if(active.equals(ai)) {
            AI.AITurn();
        } else {
            takePlayerTurn();
        }
    }

    public static void takePlayerTurn() {
        System.out.println("turn taken");
        switchPlayer();
        AI.AITurn();
    }

    private void dealStartingCards() {
        getActivePlayer().getDeck().dealCards(3);
        getOpponent().getDeck().dealCards(4);

    }

    public static void createDecks() {
//        Map<String,String> map = new HashMap<>();
//        try {
//            InputStream is = Collection.class.getResourceAsStream("cards.json");
//            Collection collection = mapper.readValue(is, Collection.class);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        System.out.println(map.toString());

        Cards aiDeck=new Cards(ai);
        Cards playerDeck=new Cards(player);
        Card sniper=new Card("GVG-808", "2055", "Steamwheedle Sniper",
                "Minion", 2, 2, 3,
                "http://media.services.zam.com/v1/media/byName/hs/cards/enus/GVG_087.png"
        );
        for(int i = 0; i < 30; i++) {
            aiDeck.addCard(sniper);
            playerDeck.addCard(sniper);
        }
        ai.setDeck(aiDeck);
        player.setDeck(playerDeck);
    }

    private static void switchPlayer(){
        if (player.getIsOnTurn()){
            player.setOnTurn(false);
            ai.setOnTurn(true);
            ai.plusMaxMana();
            ai.regenMana();
        }
        else{
            player.setOnTurn(true);
            ai.setOnTurn(false);
            player.plusMaxMana();
            player.regenMana();
        }
    }


    public void endGame() {
        String message = (player.isAlive()) ? "Victory!" : "Defeat";
    }

    public static Player getActivePlayer() {
        return (player.getIsOnTurn()) ? player : ai;
    }
	
	public static Player getOpponent() {
		return (player.getIsOnTurn()) ? ai : player;
	}

    public Player getHuman() {
        return player;
    }

    public Player getAI() {
        return ai;
    }

    public static Card getCardFromMap(String key) {
        return cardMap.get(key);
    }

    public static Minion getMinionFromMap(String key) {
        return minionMap.get(key);
    }

    public static int getUserID() {
        return userID;
    }

    public static void setUserID(int userID) {
        Game.userID = userID;
    }

    public static void addCardToMap(Card card) {
        cardMap.put(card.getUniqueID(), card);
    }

    public static void addMinionToMap(Minion minion) {
        minionMap.put(minion.getUniqueID(), minion);
    }

    public static void save(String JSON) {

    }
}
