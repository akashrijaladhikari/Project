package game;

/**
 * Created by Lev Pokazaniev on 8/05/2018.
 */
public class ChargeAbility extends Ability {
    public ChargeAbility(Actor owner) {
        super(owner);
        this.setActivateOnPlay(true);
    }
    @Override
    public void ability() {
        Actor target = GameLogic.requestEnemyTargetMinionOrPlayer();
        getOwner().attack(target);
    }
}
