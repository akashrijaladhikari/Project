package api;

import Database.SqlDatabase;
import Database.SqlStatements;
import game.Card;
import game.Game;
import game.Login;
import game.Minion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class GameApp {

    SqlDatabase db = new SqlDatabase(
            "jdbc:mysql://localhost:3306/howeststone",
            "root",
            ""
    );

    public List<Card> getMinions() {

        List<Card> minions = new ArrayList<>();
        try (
                Connection conn = db.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(SqlStatements.SElECT_MINIONS)
        ){
            while(rs.next()) {
                minions.add(new Card(rs.getString("cardID"),
                        (rs.getString("dbfid")),
                        (rs.getString("name")),
                        (rs.getString("type")),
                        (rs.getInt("cost")),
                        (rs.getInt("attack")),
                        (rs.getInt("health")),
                        (rs.getString("img"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return minions;
    }

    public Login getUser() {
        Login res = new Login("","");
        try (
                Connection conn = db.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(SqlStatements.SElECT_USER)
        ){
            while(rs.next()) {
               res = new Login(rs.getString("Email"),
                     (rs.getString("Wachtwoord")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }
    public static void executeJavascriptFunctionWithID(String uniqueID, String message, String function) {
        //TODO: send request to js to execute the function in question

    }

    public static void executeJavascriptFunction(String jsonString, String function) {
        //TODO: send request to js to execute the function in question

    }

    //TODO: write method to convert an ArrayList with cards to a json array string
    // with the corresponding uniqueID's (card/minion.getUniqueID())
    public static String cardArrayListToJSONArray(ArrayList<Card> cards) {
        String json = "";

        return json;
    }

    public static Minion requestMinionFromJS(String json, String function) {
        return Game.getMinionFromMap(
                //TODO: write requestOwnTargetMinionWithoutShield in JS which returns
                //a String with the uniqueID of the desired target minion
                requestString(json, function)
        );
    }

    private static String requestString(String json, String requestOwnTargetMinionWithoutShield) {
        //TODO: retrieving a String from JS
        String answer = "";

        return answer;
    }

    //TODO: write method to convert an ArrayList with minions to a json array string
    public static String minionArrayListToJSONArray(ArrayList<Minion> minions) {
        String json = "";

        return json;
    }
    public static String arrayToJSON(String[] parameters) {
        return "";
    }

}
