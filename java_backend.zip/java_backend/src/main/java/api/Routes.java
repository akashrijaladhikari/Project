package api;

import Database.SqlDatabase;
import Database.SqlStatements;
import com.fasterxml.jackson.databind.ObjectMapper;
import game.Card;
import game.*;
import game.GameAppConsole;
import io.javalin.Context;
import io.javalin.Javalin;

import java.util.*;

import java.io.IOException;
import java.sql.*;

class Routes {
    private final GameApp gameApp = new GameApp();
    private static ObjectMapper mapper = new ObjectMapper();

    Routes(final Javalin server) {
        // testing if the server works properly
        server.get("/", this::handleJavaToJS);
        // user input and validation
        server.post("/user/register", this::handleRegister);
        server.get("/user/login" , this::handleGetUser);
        // Deck
        server.get("/decks/getDeck" , this::handleGetDeck);
        // In game
        server.post("/game/confirmStartgame", this::handleStartgame); // starting game
        server.get("/game/getMinions", this::handleGetMinions); // getting game cards minions
//        server.get("/game/getSpelles", this::handleGetSpelles); // getting game cards spelles
        server.post("/game/JSToJava", this::handleJSToJava);
        server.get("/game/endTurn", this::handleEndTurn); // ending the turn
        server.get("/game/getAIFinished", this::handleGetAIFinished); // if ai turn is finished
        server.get("/game/getPlayerHand", this::handleGetPlayerHand); // getting player hand
        server.get("/game/getPlayerMinions", this::handleGetPlayerMinions); // getting player minions
        server.get("/game/getAIMinions", this::handleGetAIMinions); // getting ai minions
    }

    private void handleGetDeck(Context context) throws IOException {
        SqlDatabase db= new SqlDatabase(
                "jdbc:mysql://localhost:3306/howeststone",
                "root",
                "");
        try (
                Connection conn = db.getConnection();
                PreparedStatement stmt = conn.prepareStatement(SqlStatements.INSERT_DECKID)
        ){
            String json = context.body();
            Map<String,String> map = mapper.readValue(json,Map.class);
            stmt.setString(1, map.get("deckID"));
            stmt.setString(2, map.get("gebruikerID"));
            stmt.setString(3, map.get("Class"));
            stmt.setString(4, map.get("Deck Name"));
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("No decks created");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }}
    private void handleGetAIMinions(Context context) {
        List<Card> minions = gameApp.getMinions();
        context.json(minions);

//        ArrayList<Minion> aiMinions = Game.getAi().getMinions();
//        context.json(aiMinions);
    }

    private void handleGetPlayerMinions(Context context) {
        List<Card> minions = gameApp.getMinions();
        context.json(minions);

//        ArrayList<Minion> playerMinions = Game.getPlayer().getMinions();
//        context.json(playerMinions);
    }


    private void handleGetPlayerHand(Context context) {
        ArrayList<Card> playerHand = Game.getPlayer().getOnHand().getCards();
        context.json(playerHand);

        //TODO: remove testing prints
        System.out.println(Game.getPlayer());
        System.out.println(Game.getPlayer().getOnHand());
        System.out.println(Game.getPlayer().getOnHand().getCards());
    }

    private void handleGetAIFinished(Context context) {
        String bool= (AI.isFinished()) ? "true" : "false";
        String response="{finished:"+bool+"}";
        context.json(response);
    }

    private void handleEndTurn(Context context) {
        Game.takePlayerTurn();
    }

    private void handleStartgame(Context context) throws IOException {
        boolean playerStarts=GameLogic.randomBoolean();
        Map<String,String> map = handleJSToJava(context);
        printMap(map);
        Game game = new Game(
                new Player(map.get("opponent"), !playerStarts , null),
                new Player(map.get("player"), playerStarts, null),
                Integer.parseInt(map.get("userID"))
        );
        System.out.println(game.toString());
        GameAppConsole.setGame(game);
        game.start();
    }

    private void handleRegister(Context context) throws IOException {
        SqlDatabase db= new SqlDatabase(
                    "jdbc:mysql://localhost:3306/howeststone",
                    "root",
                    "");
        try (
                Connection conn = db.getConnection();
                PreparedStatement stmt = conn.prepareStatement(SqlStatements.INSERT_User,
                Statement.RETURN_GENERATED_KEYS)
                    ){
            String json = context.body();
            Map<String, String> map = mapper.readValue(json, Map.class);

                stmt.setString(1, map.get("Naam"));
                stmt.setString(2, map.get("Email"));
                stmt.setString(3, map.get("Password"));
              int affectedRows = stmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("No user created");
            }

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    long id = rs.getLong(1);
                    System.out.printf("%s now has ID %d", map.toString(), id);
                }
                else {
                    throw new SQLException("No user created");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }}

    private void handleJavaToJS(final Context context) {
        String message = "{IF YOU SEE THIS IT WORKS!}";
        context.result(message);
    }


    private void handleGetMinions(Context context){
            List<Card> minions = gameApp.getMinions();
            context.json(minions);
        }
//    private void handleGetSpelles(Context context){
//        List<Card> Spelles = gameApp.getSpells();
//        context.json(Spelles);
//    }

    private Map<String,String> handleJSToJava(Context context) throws IOException {
        System.out.println(context.formParam("uniqueID"));
        String json = context.body();
        Map<String,String> map = mapper.readValue(json, Map.class);
        System.out.println("received:" +map.toString());
        return map;
    }

    private void handleGetUser(Context context) {
        context.json(gameApp.getUser());
    }

    public static void printMap(Map map) {
        Iterator iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            System.out.println(pair.getKey() + " = " + pair.getValue());
            iterator.remove();
        }
    }
    
}
