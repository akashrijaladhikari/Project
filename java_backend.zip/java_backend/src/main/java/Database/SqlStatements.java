package Database;

public class
SqlStatements {

    public static final String SElECT_MINIONS =
            "SELECT * FROM minions WHERE playerClass = 'Hunter' OR playerClass='Neutral' ORDER BY playerClass";

    public static final String SElECT_SPELLES =
            "SELECT * FROM spelles WHERE playerClass = 'Hunter' OR playerClass='Neutral' OR playerClass = 'Mage' ORDER BY playerClass";

    public static final String SElECT_USER =
            "SELECT * FROM gebruiker";

    // decks
    public static final String INSERT_DECKID =
            "INSERT INTO decks (deckID, gebruikerID, Class, Deck Name) " +
                    "VALUES ( ?, 1,?,?)";

    public static final String CHECK_DECK =
            "SELECT * FROM deck join deck on deck.gebruikerID = gebruiker.gebruikerID WHERE gebruiker.email = ?";

    public static final String DELETE_DECK =
            "SELECT * FROM deck WHERE deckID = ?";

    /*public static final String SELECT_CAPITAL =
            "SELECT world.city.Name  FROM world.country " +
                    "INNER JOIN world.city ON world.country.Capital=world.city.ID " +
                    "WHERE world.country.Name = ?;";
*/

    public static final String INSERT_User =
            "INSERT INTO gebruiker ( Username, email, Wachtwoord) " +
                    "VALUES ( ?, ?,?)";
}


//    public static final String

